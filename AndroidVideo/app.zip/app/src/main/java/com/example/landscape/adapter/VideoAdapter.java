package com.example.landscape.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.landscape.VideoitemActivity.LoadedImage;
import com.example.landscape.R;
import com.example.landscape.domain.VideoInfo;

import java.util.ArrayList;
import java.util.List;

public class VideoAdapter extends BaseAdapter {
    private List<VideoInfo> list;
    private Context context;
    private LayoutInflater mInflater;
    private ArrayList<LoadedImage> photos = new ArrayList<LoadedImage>();
    public VideoAdapter(Context context ,List<VideoInfo> list) {
        this.context = context;
        this.list = list;
        mInflater = LayoutInflater.from(context);

    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return photos.size();
    }

    public void addPhoto(LoadedImage image){
        photos.add(image);
    }
    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder hold = null;
        if (convertView==null) {
            hold = new ViewHolder();
            convertView = mInflater.inflate(R.layout.video_item, null);
            hold.img = (ImageView) convertView.findViewById(R.id.iv_img);
            hold.tv_title = (TextView) convertView.findViewById(R.id.title);
            hold.tv_time = (TextView) convertView.findViewById(R.id.time);
            convertView.setTag(hold);
        }else{
            hold = (ViewHolder) convertView.getTag();
        }
        hold.tv_title.setText(list.get(position).getTitle());
        long min = list.get(position).getDuration() /1000 / 60;
        long sec = list.get(position).getDuration() /1000 % 60;
        hold.tv_time.setText(min+":"+sec);
        hold.img.setImageBitmap(photos.get(position).getBitmap());
        return convertView;
    }
    private final class ViewHolder{
        private ImageView img;
        private TextView tv_title;
        private TextView tv_time;

    }

}
