package com.example.landscape;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class LaunchActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.launch);
        setContentView(R.layout.launch);
        Handler handler = new Handler();
        Integer time = 1000;
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(LaunchActivity.this,VideoitemActivity.class));
                LaunchActivity.this.finish();
            }
        },time);
    }

}
