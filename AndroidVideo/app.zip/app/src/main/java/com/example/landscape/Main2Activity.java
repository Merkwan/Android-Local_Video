package com.example.landscape;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.example.landscape.domain.VideoInfo;
import com.example.landscape.danmu.mText;
import com.example.landscape.danmu.mSurfaceView;
import com.example.landscape.record.RecordService;
import com.example.landscape.utils.Utils;

import java.io.IOException;
import java.util.Random;

public class Main2Activity extends AppCompatActivity implements SurfaceHolder.Callback {
    Button btn,play,speed,record,huoqu,fasong,bofan;
    EditText editText;
    MediaPlayer mp;
    Bundle bundle;
    TextView recordtime;
    private mSurfaceView msurfaceView;
    public boolean flag=false,sign=true;
    SurfaceView surfaceView;
    Thread thread;
    SurfaceHolder surfaceHolder;
    SeekBar seek;
    int add=0,danmu=1;
    EditText input;
    Intent intent;
    Configuration configuration;
    private String urlPath ;
    private Random random=new Random();
    private String[] strings={"6666","厉害了我的国","加油！！！","欢迎收看晨间新闻","程序猿很苦逼","我能怎么办，我也很无奈"};
    private int[] colors={Color.WHITE,Color.MAGENTA,Color.CYAN,Color.YELLOW,Color.BLUE,Color.GREEN};
    TextView loding,start_time,end_time,recordTime;
    static float speed_=1.0f;
    boolean isReord;
    int screenWidth;
    int screenHeight;
    int screenDensity;
    String START="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        intent = this.getIntent();
        Bundle bundle = intent.getExtras();
        VideoInfo video = (VideoInfo) bundle.getSerializable("videoInfo");
        urlPath = video.getPath();
        initView();
        RelativeLayout.LayoutParams params=new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT,700);
        bofan.setVisibility(View.GONE);
        fasong.setVisibility(View.GONE);
        record.setVisibility(View.GONE);
        recordTime.setVisibility(View.GONE);
        editText.setVisibility(View.GONE);
        huoqu.setVisibility(View.GONE);
        surfaceView.setLayoutParams(params);
//
        huoqu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent();
                i.setClass(Main2Activity.this,VideoitemActivity.class);
                startActivity(i);
            }
        });
        bofan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                danmu++;
             if(danmu%2==0) {
                 msurfaceView.surfaceCreated(surfaceHolder);
                 startBarrage();
                 bofan.setBackground(getResources().getDrawable(R.drawable.bullet_on));
             }
             else
             {
                 msurfaceView.Barrages.clear();
                 bofan.setBackground(getResources().getDrawable(R.drawable.bullet_off));
             }
             }
        });
        fasong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startBarragesend();
                editText.setText("");
            }
        });

        if(Build.VERSION.SDK_INT>=23){
            int REQUEST_CODE_CONTACT = 101;
            String[] permissions = {Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
            //验证是否许可权限
            for (String str : permissions) {
                if (this.checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {
                    //申请权限
                    this.requestPermissions(permissions, REQUEST_CODE_CONTACT);
                }
            }
        }
        //加载视屏
        //confirm.setOnClickListener(new View.OnClickListener() {
           // @Override
          //  public void onClick(View v) {
              //  input.setText("");
           // }
         //});
        //播放视屏
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(sign==true) {play(urlPath);sign=false;}
                if(loding.getText().toString().equals("加载完毕,开始播放!")&&!mp.isPlaying())
                {
                    mp.start();
                    new SEEK().start();
                    play.setBackground(getResources().getDrawable(R.drawable.play));
                    loding.setVisibility(View.GONE);
                }
                else if(loding.getText().toString().equals("加载完毕,开始播放!")&&mp.isPlaying())
                {
                    mp.pause();
                    play.setBackground(getResources().getDrawable(R.drawable.pause));
                }
                else if(loding.getText().toString().equals("加载完毕,开始播放!"))
                {
                    mp.stop();
                    loding.setText("加载中...");
                }
            }
        });
        //停止
//        stop.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(loding.getText().toString().equals("加载完毕,开始播放!"))
//                {
//                    mp.stop();
//                    speed_=1.0f;
//                    speed.setText(speed_+"X");
//                    loding.setText("加载中...");
//                    speed.setVisibility(View.VISIBLE);
//                    loding.setVisibility(View.VISIBLE);
//                    btn.setVisibility(View.VISIBLE);
//                    play.setVisibility(View.VISIBLE);
//                    seek.setVisibility(View.VISIBLE);
//                    start_time.setVisibility(View.VISIBLE);
//                    end_time.setVisibility(View.VISIBLE);
//                }
//            }
//        });
        //横屏
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getResources().getConfiguration().orientation==ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
                {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                }
                else
                {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                }
            }
        });
        //倍速
        speed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(loding.getText().toString().equals("加载完毕,开始播放!"))
                {
                    if(speed_<4.0)
                    {
                        speed_+=0.5;
                        mp.setPlaybackParams(mp.getPlaybackParams().setSpeed(speed_));
                        speed.setText(""+speed_+"X");
                    }
                    else
                    {
                        speed_=1.0f;
                        mp.setPlaybackParams(mp.getPlaybackParams().setSpeed(speed_));
                        speed.setText(""+speed_+"X");
                    }
                }
            }
        });
        //触摸视屏
        surfaceView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(mp!=null&&loding.getText().toString().equals("加载完毕,开始播放!"))
                {
                    int ri =getConf();
                    add++;
                    if(add%2==1)
                    {

                        start_time.setVisibility(View.GONE);
                        end_time.setVisibility(View.GONE);
                        loding.setVisibility(View.GONE);
                        play.setVisibility(View.GONE);
                        btn.setVisibility(View.GONE);
                        seek.setVisibility(View.GONE);
                        speed.setVisibility(View.GONE);
                        if(ri==configuration.ORIENTATION_LANDSCAPE){
                        bofan.setVisibility(View.GONE);
                        fasong.setVisibility(View.GONE);
                        record.setVisibility(View.GONE);
                        editText.setVisibility(View.GONE);
                        huoqu.setVisibility(View.GONE);
                        recordTime.setVisibility(View.GONE);
                        }
                        if(mp.isPlaying())  play.setBackground(getResources().getDrawable(R.drawable.play));
                        else if(!mp.isPlaying()) play.setBackground(getResources().getDrawable(R.drawable.pause));
                    }
                    else if (add%2==0)
                    {
                        if(ri==configuration.ORIENTATION_LANDSCAPE) {
                        bofan.setVisibility(View.VISIBLE);
                        fasong.setVisibility(View.VISIBLE);
                        record.setVisibility(View.VISIBLE);
                        editText.setVisibility(View.VISIBLE);
                        huoqu.setVisibility(View.VISIBLE);
                        recordTime.setVisibility(View.VISIBLE);
                        }
                        play.setVisibility(View.VISIBLE);
                        btn.setVisibility(View.VISIBLE);
                        seek.setVisibility(View.VISIBLE);
                        speed.setVisibility(View.VISIBLE);
                        start_time.setVisibility(View.VISIBLE);
                        end_time.setVisibility(View.VISIBLE);
                        if(mp.isPlaying())  play.setBackground(getResources().getDrawable(R.drawable.play));
                        else if(!mp.isPlaying()) play.setBackground(getResources().getDrawable(R.drawable.pause));
                    }
//                    if(mp.isPlaying())
//                    {
//                        //mp.pause();
//                        play.setVisibility(View.VISIBLE);
//                        btn.setVisibility(View.VISIBLE);
//                        seek.setVisibility(View.VISIBLE);
//                        speed.setVisibility(View.VISIBLE);
//                        play.setBackground(getResources().getDrawable(R.drawable.pause));
//                        start_time.setVisibility(View.VISIBLE);
//                        end_time.setVisibility(View.VISIBLE);
//                    }
//                    else
//                    {
//                        if(!mp.isPlaying())
//                        {


                           // mp.start();
//                            play.setBackground(getResources().getDrawable(R.drawable.play));
//                            start_time.setVisibility(View.GONE);
//                            end_time.setVisibility(View.GONE);
//                            loding.setVisibility(View.GONE);
//                            play.setVisibility(View.GONE);
//                            btn.setVisibility(View.GONE);
//                            seek.setVisibility(View.GONE);
//                            speed.setVisibility(View.GONE);
 //                       }
 //                   }
                }
                return false;
            }
        });
        //进度条
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                seek.setProgress(progress);
                String str=getTime((progress/1000));
                start_time.setText(str);
                if(isReord)
                {
                    recordTime.setText(str);
                }
                if(fromUser)
                {
                    mp.seekTo(progress);
                    seek.setProgress(progress);
                }

            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isReord)
                {
                    stopRecord();
                }
                else
                {
                    startRecord();
                }
            }
        });
    }
     int  getConf( )
    {
        Configuration configuration1;
        configuration1 = this.getResources().getConfiguration();
        return configuration1.orientation;
    }
    //加载视屏
    public void play(String str)
    {
        mp.reset();
        mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
        Uri uri=Uri.parse(urlPath);
         try {
//            if(ContextCompat.checkSelfPermission(Main2Activity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
//            {
//                ActivityCompat.requestPermissions(Main2Activity.this,new String[]{ Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
//            }
//            File file=new File(urlPath);
//            if(file.exists())
//            {
                mp.setDataSource(Main2Activity.this,uri);
                mp.setDisplay(surfaceHolder);
                mp.setScreenOnWhilePlaying(true);
                mp.prepare();
                //mp.prepareAsync();
//                mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
//                    @Override
//                    public void onPrepared(MediaPlayer mp) {
                        loding.setVisibility(View.VISIBLE);
                        loding.setText("加载完毕,开始播放!");
                        int e=mp.getDuration()/1000;
                        String stre=getTime(e);
                        end_time.setText("/"+stre);
                        seek.setMax(mp.getDuration());
                   // }
              //  });
           // }
//            else
//            {
//                loding.setText("资源不存在，请重新输入!");
//            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onPause()
    {
        super.onPause();
        if(mp.isPlaying())
        {
            mp.pause();
        }
    }
    @Override
    public void onStop()
    {
        super.onStop();
        if(mp.isPlaying())
        {
            mp.pause();
        }
    }
    @Override
    public void onDestroy()
    {
        super.onDestroy();
        if(mp.isPlaying())
        {
            mp.stop();
        }
        mp.release();
    }
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        holder.addCallback(this);
        mp.setDisplay(surfaceHolder);
    }
    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        holder.addCallback(this);
        mp.setDisplay(surfaceHolder);
    }
    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

    }
    @Override
    public void onConfigurationChanged(Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);
        if(newConfig.orientation==Configuration.ORIENTATION_LANDSCAPE)
        {
            int heigth=mp.getVideoHeight();
            int width=mp.getVideoWidth();
            surfaceHolder.setFixedSize(100,50);
            DisplayMetrics dm =getResources().getDisplayMetrics();
            int W=dm.widthPixels;
                bofan.setVisibility(View.VISIBLE);
                fasong.setVisibility(View.VISIBLE);
                record.setVisibility(View.VISIBLE);
                editText.setVisibility(View.VISIBLE);
                huoqu.setVisibility(View.VISIBLE);
                recordTime.setVisibility(View.VISIBLE);

            RelativeLayout.LayoutParams params=new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT,W);
            surfaceView.setLayoutParams(params);
        }
        else
        {
            RelativeLayout.LayoutParams params=new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT,700);
            bofan.setVisibility(View.GONE);
            fasong.setVisibility(View.GONE);
            record.setVisibility(View.GONE);
            editText.setVisibility(View.GONE);
            huoqu.setVisibility(View.GONE);
            recordTime.setVisibility(View.GONE);
            surfaceView.setLayoutParams(params);
        }
    }
    public void initView()
    {
        bofan=(Button)findViewById(R.id.bofan);
        fasong=(Button)findViewById(R.id.fasong);
        //guanbi=(Button) findViewById(R.id.guanbi);
        recordTime=(TextView)findViewById(R.id.recordTime);
        msurfaceView = (mSurfaceView)findViewById(R.id.msv);
        editText=(EditText)findViewById(R.id.edittext);
        huoqu=(Button)findViewById(R.id.huoqu);
        btn=(Button)findViewById(R.id.btn);
        play=(Button)findViewById(R.id.play);
        speed=(Button)findViewById(R.id.speed);
        speed.setText("1.0X");
        //confirm=(Button)findViewById(R.id.comfirm);
        record=(Button)findViewById(R.id.record);
        //stop=(Button)findViewById(R.id.stop);
        surfaceView=(SurfaceView)findViewById(R.id.surfaceView);
        seek=(SeekBar)findViewById(R.id.seekbar);
        //input=(EditText)findViewById(R.id.input);
        loding=(TextView)findViewById(R.id.loding);
        start_time=(TextView)findViewById(R.id.start_time);
        end_time=(TextView)findViewById(R.id.end_time);
        recordTime=(TextView)findViewById(R.id.recordTime);
        mp=new MediaPlayer();
        getScreenBaseInfo();
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.setKeepScreenOn(true);
        surfaceHolder.setFixedSize(100,100);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        surfaceHolder.addCallback(this);
    }
    //获取时间
    public String getTime(int time)
    {
        if(time<60)
        {
            if(time<10)
            {
                return "00:0"+time;
            }
            else
            {
                return "00:"+time;
            }
        }
        else {
            if (time < 600) {
                if(time%60<10)
                {
                    return "0" + time / 60 + ":0" + time % 60;
                }
                else
                {
                    return "0" + time / 60 + ":" + time % 60;
                }

            } else
            {
                return time/60+":"+time%60;
            }
        }
    }
    //获取屏幕信息
    private void getScreenBaseInfo() {
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        //屏幕宽度
        screenWidth = metrics.widthPixels;
        //屏幕高度
        screenHeight = metrics.heightPixels;
        //像素
        screenDensity = metrics.densityDpi;
    }
    //开始录制
    public void startRecord(){
        thread=new Thread(new Runnable() {
        @Override
        public void run() {
        MediaProjectionManager mediaProjectionManager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        Intent permissionIntent = mediaProjectionManager.createScreenCaptureIntent();
        startActivityForResult(permissionIntent,1000);
        isReord = true;
        record.setBackground(getResources().getDrawable(R.drawable.bgrecordstop));
         }
    });thread.start();
}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1000){
            //权限申请成功
            if(resultCode==RESULT_OK){
                //创建Intent，并传递信息
                Intent intent = new Intent(this, RecordService.class);
                intent.putExtra("resultCode",resultCode);
                intent.putExtra("resultData",data);
                intent.putExtra("screenWidth",screenWidth);
                intent.putExtra("screenHeight",screenHeight);
                intent.putExtra("screenDensity",screenDensity);
                //启动service
                startService(intent);
                //提示消息
                Utils.ShowToast(this,"开始录制！");
            }else{
                Utils.ShowToast(this,"录屏失败");
            }
        }
    }

    public void stopRecord(){
        //停止Service
        Intent intent = new Intent(this,RecordService.class);
        stopService(intent);
        isReord =false;
        record.setBackground(getResources().getDrawable(R.drawable.bg_record_on));
    }
    void startBarrage() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (danmu%2==0){
                    mText mText=new mText();
                    mText.setText(strings[random.nextInt(strings.length)]);
                    mText.setSpeed(3);
                    mText.setColor(colors[random.nextInt(colors.length)]);
                    mText.setSize(40);
                    msurfaceView.add(mText);
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }
    void startBarragesend() {
        thread=new Thread(new Runnable() {
            @Override
            public void run() {
                mText mText=new mText();
                mText.setText(editText.getText().toString());
                mText.setSpeed(2);
                mText.setColor(Color.RED);
                mText.setSize(60);
                msurfaceView.add(mText);
                   /* try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }*/
            }
        });thread.start();
    }
    class SEEK extends Thread
    {
        @Override
        public void run()
        {
            while(mp!=null)
            {

                seek.setProgress(mp.getCurrentPosition());
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }
    }
}
