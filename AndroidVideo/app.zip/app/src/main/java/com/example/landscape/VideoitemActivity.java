package com.example.landscape;

import java.util.List;

import com.example.landscape.adapter.VideoAdapter;
import com.example.landscape.domain.VideoInfo;
import com.example.landscape.utils.GetVideoInfoUtils;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.media.ThumbnailUtils;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore.Video.Thumbnails;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageView;

public class VideoitemActivity extends Activity {
    private GridView gridview;
    VideoAdapter mAdapter;
    List<VideoInfo> listVideos;
    int videoSize;
    AlertDialog alert_progress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.videoitem_activity);
        GetVideoInfoUtils provider = new GetVideoInfoUtils(this);
        listVideos = provider.getList();
        videoSize = listVideos.size();
        gridview = (GridView) findViewById(R.id.gridview);
        mAdapter = new VideoAdapter(this, listVideos);
        gridview.setAdapter(mAdapter);
        gridview.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                intent.setClass(VideoitemActivity.this, Main2Activity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("videoInfo", listVideos.get(position));
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        loadImages();
        showDialog();
    }


    private void showDialog(){
        // 自定义弹出框,框内放入图片,图片设置旋转动画
        alert_progress = new AlertDialog.Builder(VideoitemActivity.this).create();
        alert_progress.show();
        alert_progress.setCancelable(false); // 点击背景时对话框不会消失
        // alert_progress.dismiss(); // 取消对话框
        Window window = alert_progress.getWindow();
        window.setContentView(R.layout.dialog_a); //加载自定义的布局文件
        WindowManager.LayoutParams wm = window.getAttributes();
        wm.width = 300; // 设置对话框的宽
        wm.height = 350; // 设置对话框的高
        wm.alpha = 0.5f;   // 对话框背景透明度
        wm.dimAmount = 0.6f; // 遮罩层亮度
        window.setAttributes(wm);

        ImageView img = (ImageView)window.findViewById(R.id.progress_bar);  // 获取布局文件中的ImageView控件
        img.setBackgroundResource(R.drawable.jiazai); // 设置图片，也可在布局文件中设置

        // 设置旋转动画
        Animation tranfrom = new RotateAnimation(0,359,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);//(359:旋转角度（可自调），若为360会有卡顿，正数为顺势针旋转，负数为逆时针)
        tranfrom.setDuration(2000); // 旋转速度
        tranfrom.setFillAfter(true);
        tranfrom.setRepeatCount(-1); // －1为一只旋转，若10，则旋转10次设定的角度后停止
        // tranfrom.cancel();  // 取消动画
        img.setAnimation(tranfrom);
    }

    /**
     * Load images.
     */
    private void loadImages() {
        final Object data = getLastNonConfigurationInstance();
        if (data == null) {
            new LoadImagesFromSDCard().execute();
        } else {
            final LoadedImage[] photos = (LoadedImage[]) data;
            if (photos.length == 0) {
                new LoadImagesFromSDCard().execute();
            }
            for (LoadedImage photo:photos) {
                addImage(photo);
            }
        }
    }
    private void addImage(LoadedImage... value) {
        for (LoadedImage image : value) {
            mAdapter.addPhoto(image);
            mAdapter.notifyDataSetChanged();
        }
    }
    @Override
    public Object onRetainNonConfigurationInstance() {
        final GridView  grid = gridview;
        final int count = grid.getChildCount();
        final LoadedImage[] list = new LoadedImage[count];

        for (int i = 0; i < count; i++) {
            final ImageView v = (ImageView) grid.getChildAt(i);
            list[i] = new LoadedImage(
                    ((BitmapDrawable) v.getDrawable()).getBitmap());
        }

        return list;
    }
    /**
     *
     * @param videoPath
     * @param width
     * @param height
     * @param kind
     * @return
     */
    private Bitmap getVideoThumbnail(String videoPath, int width , int height, int kind){
        Bitmap bitmap = null;
        bitmap = ThumbnailUtils.createVideoThumbnail(videoPath, kind);
        bitmap = ThumbnailUtils.extractThumbnail(bitmap, width, height, ThumbnailUtils.OPTIONS_RECYCLE_INPUT);
        return bitmap;
    }

    class LoadImagesFromSDCard extends AsyncTask<Object, LoadedImage, Object> {

        @Override
        protected void onPreExecute() {
//			   alert_progress.show();
        }
        @Override
        protected Object doInBackground(Object... params) {
            Bitmap bitmap = null;
            for (int i = 0; i < videoSize; i++) {
                bitmap = getVideoThumbnail(listVideos.get(i).getPath(), 120, 120, Thumbnails.MINI_KIND);
                if (bitmap != null) {
                    publishProgress(new LoadedImage(bitmap));
                }
            }
            return null;
        }

        @Override
        public void onProgressUpdate(LoadedImage... value) {
            addImage(value);
        }
        @Override
        protected void onPostExecute(Object result) {
            alert_progress.cancel();
        }
    }

    public class LoadedImage {
        Bitmap mBitmap;

        public LoadedImage(Bitmap bitmap) {
            mBitmap = bitmap;
        }

        public Bitmap getBitmap() {
            return mBitmap;
        }
    }
}
