package com.example.landscape.record;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RecordService extends Service {
    private int resultCode;
    private Intent resultData = null;
    private MediaProjection mediaProjection = null;
    private MediaRecorder mediaRecorder = null;
    private VirtualDisplay virtualDisplay = null;
    private int screenWidth;
    private int screenHeight;
    private int screenDensity;
    private Context context=null;
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("创建service","----------------");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
           //接受Intent信息
        resultCode = intent.getIntExtra("resultcode",-1);
        resultData = intent.getParcelableExtra("resultData");
        screenWidth=intent.getIntExtra("screenWidth",0);
        screenHeight=intent.getIntExtra("screenHeight",0);
        screenDensity=intent.getIntExtra("screenDensity",0);
        //创建mediaProjection实例
        mediaProjection = createProjection();
        //创建mediaRecorder实例
        mediaRecorder = createMediaRecorder();
        //创建virtualDisplay实例
        virtualDisplay = createVirtualDisplay();
        //准备就绪后，开始录制
        mediaRecorder.start();
        return Service.START_NOT_STICKY;
    }


    public MediaProjection createProjection(){
        //固定写法
        return ((MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE))
                .getMediaProjection(resultCode,resultData);
    }
    public MediaRecorder createMediaRecorder(){
        String directoryPath = Environment.getExternalStorageDirectory().getPath()+"/AAA";
         File file = new File(directoryPath);
         if(!file.exists()){
             file.mkdirs();
         }
        //new一个对象
         MediaRecorder mediaRecorder = new MediaRecorder();
         //获取存储路径:文件名为当前的时间
        SimpleDateFormat dateFormat = new SimpleDateFormat("YY-MM-dd-hh-mm-ss");
        String filePath =file.getAbsolutePath()+"/"+dateFormat.format(new Date())+".mp4";
        //设置录制视频的source
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.DEFAULT);
        mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        //设置输出格式
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4 );
        //设置视频比特率.
        mediaRecorder.setVideoEncodingBitRate(5*screenWidth*screenHeight);
        //设置视频encoder
        mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        //设置视频屏幕大小
        mediaRecorder.setVideoSize(screenWidth,screenHeight);
        //设置帧率
        mediaRecorder.setVideoFrameRate(60);
        //准备录制
        try {
            mediaRecorder.setOutputFile(filePath);
            mediaRecorder.prepare();
        } catch (IOException e) {
            Log.d("准备失败","---------------");
            e.printStackTrace();
        }
        return  mediaRecorder;
    }
    public VirtualDisplay createVirtualDisplay(){
        return mediaProjection.createVirtualDisplay("mediaProjection",screenWidth,screenHeight,screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,mediaRecorder.getSurface(),null,null);
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {//资源释放
        super.onDestroy();
        super.onDestroy();
        if(virtualDisplay!=null){
            virtualDisplay.release();
            virtualDisplay=null;
        }
        if(mediaRecorder!=null){
            mediaRecorder.stop();
            mediaRecorder=null;
        }
        if(mediaProjection!=null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
    }

}
